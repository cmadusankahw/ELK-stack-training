export default {
  props: {
    content: {
      type: String,
    },
    removable: {
      type: Boolean,
    },
    valid: {
      type: Boolean,
    },
  },
  template: 'local',
};
