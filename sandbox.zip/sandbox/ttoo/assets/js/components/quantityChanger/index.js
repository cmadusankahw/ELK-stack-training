export default {
  props: {
    id: {
      type: String,
    },
    value: {
      required: true,
      type: Number,
    },
  },
  template: 'local',
};
